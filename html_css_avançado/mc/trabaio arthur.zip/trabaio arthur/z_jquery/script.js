$(document).ready(function() {
    $("#teste").click(function() {
        $(this).hide();
    });
});

$(document).ready(function() {
    $().mouseout()
});